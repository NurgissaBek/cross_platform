import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:to_do_app/Data/network/firebase/firebase_services.dart';
import 'package:to_do_app/Data/shared%20pref/shared_pref.dart';
import 'package:to_do_app/utils/utils.dart';
import 'package:to_do_app/view%20model/DbHelper/db_helper.dart';
import '../../model/task_model.dart';
import 'package:intl/intl.dart';


class HomeController extends GetxController {
  RxMap userData = {}.obs;
  RxString name = ''.obs;
  RxBool focus = false.obs;
  RxBool hasText = false.obs;
  RxInt taskCount = 0.obs;
  RxBool hasData = false.obs;
  RxString selectedCategory = 'all'.obs;
  RxString selectedPriority = 'all'.obs;
  RxString selectedSort = 'none'.obs; // none, title, date
  Rx<DateTime?> selectedDate = Rx<DateTime?>(null);

  RxString selectedFilter = 'all'.obs; // all, completed, unComplete
  final DbHelper db = DbHelper();
  RxList<TaskModel> list = <TaskModel>[].obs;
  Connectivity? connectivity;
  final searchController = TextEditingController().obs;
  List<TaskModel> get filteredTasks {
    List<TaskModel>? filtered = list.value;

    // ФИЛЬТРЫ
    if (selectedFilter.value != 'all') {
      filtered = filtered
          .where((task) => task.status == selectedFilter.value)
          .toList();
    }

    if (selectedCategory.value != 'all') {
      filtered =
          filtered.where((task) => task.category == selectedCategory.value).toList();
    }

    if (selectedPriority.value != 'all') {
      filtered =
          filtered.where((task) => task.periority == selectedPriority.value).toList();
    }

    if (selectedDate.value != null) {
      final formatted = DateFormat('dd/MM/yyyy').format(selectedDate.value!);
      filtered = filtered.where((task) => task.date == formatted).toList();
    }

    if (searchController.value.text.trim().isNotEmpty) {
      final query = searchController.value.text.trim().toLowerCase();
      filtered = filtered.where((task) => task.title!.toLowerCase().contains(query)).toList();
    }



    // СОРТИРОВКА
    switch (selectedSort.value) {
      case 'title_asc':
        filtered.sort((a, b) => a.title!.compareTo(b.title!));
        break;
      case 'title_desc':
        filtered.sort((a, b) => b.title!.compareTo(a.title!));
        break;
      case 'date_asc':
        filtered.sort((a, b) => a.date!.compareTo(b.date!));
        break;
      case 'date_desc':
        filtered.sort((a, b) => b.date!.compareTo(a.date!));
        break;
      case 'priority_high':
        filtered.sort((a, b) => b.periority!.compareTo(a.periority!)); // если 'High' > 'Low'
        break;
      case 'priority_low':
        filtered.sort((a, b) => a.periority!.compareTo(b.periority!));
        break;
    }
    update();
    return filtered;
  }


  HomeController() {
    // if name not loaded
    if (userData['NAME'] == null) {
      getUserData();
    }
    // check for set listeners only for one time
    if (connectivity == null) {
      String? email = FirebaseService.auth.currentUser?.email;
      if (email == null) return;
      String node = email.substring(0, email.indexOf('@'));

      // listener for changing live database
      FirebaseDatabase.instance
          .ref('Tasks')
          .child(node)
          .onValue
          .listen((event) async {
        int count = await FirebaseService.childCount();
        // check if live database has more child than local

        getTaskData();
        for (var element in event.snapshot.children) {
          if (!await db.isRowExists(
              element.child('key').value.toString(), 'Tasks')) {
            db
                .insert(
              TaskModel(
                  key: element.child('key').value.toString(),
                  time: element.child('time').value.toString(),
                  status: element.child('status').value.toString(),
                  date: element.child('date').value.toString(),
                  periority: element.child('periority').value.toString(),
                  description: element.child('description').value.toString(),
                  category: element.child('category').value.toString(),
                  title: element.child('title').value.toString(),
                  image: element.child('image').value.toString(),
                  show: element.child('show').value.toString()),
            )
                .then((value) {
              getTaskData();
            });
          }
        }
      });

      FirebaseDatabase.instance
          .ref('Tasks')
          .child(node)
          .onChildChanged
          .listen((event) async {
        int count = await FirebaseService.childCount();

        // check if live database has more child than local
        getTaskData();
        for (var element in event.snapshot.children) {
          db
              .update(TaskModel(
              status: element.child('status').value.toString(),
                  key: element.child('key').value.toString(),
                  time: element.child('time').value.toString(),
                  date: element.child('date').value.toString(),
                  periority: element.child('periority').value.toString(),
                  description: element.child('description').value.toString(),
                  category: element.child('category').value.toString(),
                  title: element.child('title').value.toString(),
                  image: element.child('image').value.toString(),
                  show: element.child('show').value.toString()))
              .then((value) {
            getTaskData();
          });
        }
      });
      connectivity = Connectivity();
      // listener for internet state
      connectivity!.onConnectivityChanged.listen((event) async {
        if (event == ConnectivityResult.mobile ||
            event == ConnectivityResult.wifi) {
          var list = await db.getPendingUploads();
          for (int i = 0; i < list.length; i++) {
            db.insert(list[i]);
            db.delete(list[i].key!, 'PendingUploads');
          }
          list.clear();
          list = await db.getPendingDeletes();
          for (int i = 0; i < list.length; i++) {
            FirebaseService.update(list[i].key!, 'show', 'no');
            db.delete(list[i].key!, 'PendingDeletes');
          }
          getTaskData();
        }
      });
    }
    getTaskData();
  }
  checkData() {
    int count = 0;
    for (int i = 0; i < list.length; i++) {
      if (list[i].show == 'yes') {
        count++;
      }
    }
    if (count > 0) {
      hasData.value = true;
      taskCount.value = count;
    } else {
      hasData.value = false;
      taskCount.value = 0;
    }
  }
  popupMenuSelected(int value, int index, BuildContext context) async {
    if (value == 2) {
      Utils.showWarningDailog(context, () => removeFromList(index));
    }
  }
  getTaskData() async {
    list.value = await db.getData();
    var tempList = await db.getPendingUploads();
    for (int i = 0; i < tempList.length; i++) {
      list.add(tempList[i]);
    }
    checkData();
  }
  Future<List<TaskModel>> getFututeData() {
    return db.getData();
  }
  onClear(BuildContext context) {
    searchController.value.text = '';
    hasText.value = false;
    onTapOutside(context);
  }
  onTapOutside(BuildContext context) {
    focus.value = false;
    FocusScope.of(context).unfocus();
  }
  checkText() {
    hasText.value = searchController.value.text.toString().isNotEmpty;
    update();
  }
  onTapField() {
    focus.value = true;
  }
  getUserData() async {
    userData.value = await UserPref.getUser();
    getName();
  }
  getName() {
    name.value = userData['NAME']
        .toString()
        .substring(0, userData['NAME'].toString().indexOf(' '));
  }
  removeFromList(int index) {
    db
        .removeFromList(TaskModel(
            key: list[index].key,
            status: list[index].status,
            time: list[index].time,
            date: list[index].date,
            periority: list[index].periority,
            description: list[index].description,
            category: list[index].category,
            title: list[index].title,
            image: list[index].image,
            show: 'no'))
        .then((value) {
      getTaskData();
    });
  }
  Future<void> updateTask(int index, TaskModel updatedTask) async {
  // 1) сразу меняем локальный список, чтобы UI обновился мгновенно
  list[index] = updatedTask;
  update();

  // 2) кидаем апдейт в SQLite
  await db.update(updatedTask);

  // 3) если есть сеть — продублируем в Firebase
  final connection = await connectivity?.checkConnectivity();
  if (connection == ConnectivityResult.mobile ||
      connection == ConnectivityResult.wifi) {
    // FirebaseServices.update обновляет одно поле за раз,
    // поэтому прогоним по нужным ключам:
    await FirebaseService.update(updatedTask.key!, 'title',       updatedTask.title!);
    await FirebaseService.update(updatedTask.key!, 'description', updatedTask.description!);
    await FirebaseService.update(updatedTask.key!, 'category',    updatedTask.category!);
  } else {
    // офлайн-режим — кладём в PendingUploads, если он у тебя используется
    await db.insert(updatedTask);
  }
}

}

class Routes{
  static const splashScreen='/';
  static const signUpScreen='/signUpScreen';
  static const signInScreen='/signInScreen';
  static const homePage='/homePage';
  static const String profile = '/profile';
}